# IMS Group Website

A complete, professional multi-page website for IMS Group — Rwanda's leading digital business management systems company.

## 📁 File Structure

```
/ims-website
├── index.html          → Homepage (Hero, Products preview, Testimonials)
├── about.html          → About page (Mission, Vision, Team, Values)
├── products.html       → Products catalog with DRAG & DROP image upload
├── product-details.html → Dynamic product detail page with screenshot upload
├── training.html       → Training programs page
├── purchase.html       → Purchase page with payment form
├── demo.html           → Demo request page
├── contact.html        → Contact page with form
├── css/
│   └── style.css       → All styles (1 unified stylesheet)
├── js/
│   ├── main.js         → Interactions (forms, scroll effects, animations)
│   └── components.js   → Shared nav and footer injected into all pages
└── images/             → Place product images and screenshots here
```

## 🚀 How to Run in VS Code

### Option 1 — Live Server (Recommended)
1. Open the `ims-website` folder in VS Code
2. Install the **Live Server** extension (by Ritwick Dey)
3. Right-click `index.html` → **"Open with Live Server"**
4. The site opens at `http://127.0.0.1:5500`

### Option 2 — Simple file open
1. Double-click `index.html` to open in your browser
2. Navigate between pages using the navigation bar

## 📦 Adding Products (Drag & Drop)

Go to **Products page** (`products.html`):

1. **Upload product images**: Drag and drop images into the upload zone at the top
2. **Add a new product**: Click the **"+ Add New Product"** button
   - Fill in: Name, Category, Price, Description, Icon/Emoji
   - Upload a product image (drag & drop or browse)
   - Click **"Add Product"** — it appears instantly in the catalog
3. **Change product image**: Each product card has a **"📷 Change Image"** button

Go to **Product Details page**:
- Upload screenshots of any product by dragging them into the screenshot zone
- The first screenshot uploaded becomes the main product image

## 🛍️ Pages Overview

| Page | File | Description |
|------|------|-------------|
| Home | index.html | Hero, features, products preview, testimonials |
| About | about.html | Company story, mission, vision, team |
| Products | products.html | Full product catalog + drag & drop upload |
| Product Detail | product-details.html | Per-product info, features, pricing |
| Training | training.html | Training programs and registration |
| Purchase | purchase.html | Order form + payment methods |
| Demo | demo.html | Demo booking form |
| Contact | contact.html | Contact info + message form |

## 💳 Payment Methods Included
- MTN MoMo (with payment instructions)
- Airtel Money (with payment instructions)  
- Mastercard (with card form)

## 🎨 Design Matching Prototype
- Dark navy navbar matching prototype exactly
- "Book a Demo" CTA button (top right)
- Dashboard mockup in hero (tablet + phone overlay)
- Stats bar (1000+ Organizations, 50+ Trainers, 15+ Industries, 99% Satisfaction)
- IMS Suite product box with 3D perspective
- "Everything You Need to Manage. All in One Place." features section

## 📱 Responsive Design
- Desktop, tablet, and mobile layouts
- Hamburger menu on mobile
- Fluid typography and grid breakpoints

## ✅ Features
- ✅ Floating WhatsApp button on all pages
- ✅ Smooth scroll animations
- ✅ Hover effects on all cards and buttons
- ✅ Form validation + success messages
- ✅ URL parameters (e.g. `product-details.html?id=bar`)
- ✅ Active nav item highlighting
- ✅ Drag & drop product image upload
- ✅ Add new products via modal form
- ✅ Per-product image replacement

## 🔧 Customization

**Change company details**: Edit `js/components.js` — update phone number, email, WhatsApp link

**Add more products**: Edit `products.html` — copy a product card and update the content

**Change colors**: Edit `css/style.css` — update the CSS variables at the top (`--navy`, `--blue`, etc.)

**Add payment gateway**: Replace the form submission in `js/main.js` with your actual payment API

## 📞 Contact Info (Update These)
- Phone: +250 780 000 000
- Email: info@imsgroup.rw
- WhatsApp: https://wa.me/250780000000
- Location: Kigali, Rwanda
