// IMS GROUP - SHARED COMPONENTS

const NAV_HTML = `
<nav class="navbar">
  <a class="nav-brand" href="index.html">
    <div class="logo-icon"></div>
    <div class="brand-text">
      <span class="brand-name">IMS <span>GROUP</span></span>
      <span class="brand-sub">Integrated Management Systems</span>
    </div>
  </a>

  <div class="nav-menu">
    <div class="nav-item" data-page="index.html">
      <a href="index.html">Solutions</a>
      <svg viewBox="0 0 12 12" fill="currentColor"><path d="M2 4l4 4 4-4"/></svg>
      <div class="nav-dropdown">
        <a href="product-details.html?id=bar">Bar Management System</a>
        <a href="product-details.html?id=retail">Retail Management System</a>
        <a href="product-details.html?id=restaurant">Restaurant System</a>
        <a href="product-details.html?id=hotel">Hotel Management System</a>
        <a href="product-details.html?id=pharmacy">Pharmacy System</a>
        <a href="products.html">View All Products →</a>
      </div>
    </div>
    <a class="nav-item" href="training.html" data-page="training.html">Training</a>
    <a class="nav-item" href="products.html" data-page="products.html">Platform</a>
    <a class="nav-item" href="products.html" data-page="products.html">Industries</a>
    <a class="nav-item" href="purchase.html" data-page="purchase.html">Pricing</a>
    <div class="nav-item">
      Resources
      <svg viewBox="0 0 12 12" fill="currentColor"><path d="M2 4l4 4 4-4"/></svg>
      <div class="nav-dropdown">
        <a href="#">Documentation</a>
        <a href="#">Case Studies</a>
        <a href="#">Blog</a>
        <a href="contact.html">Support</a>
      </div>
    </div>
    <div class="nav-item">
      Company
      <svg viewBox="0 0 12 12" fill="currentColor"><path d="M2 4l4 4 4-4"/></svg>
      <div class="nav-dropdown">
        <a href="about.html">About Us</a>
        <a href="about.html#team">Our Team</a>
        <a href="contact.html">Contact</a>
      </div>
    </div>
  </div>

  <div class="nav-actions">
    <button class="nav-icon-btn" title="Cart" onclick="window.location='purchase.html'">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 001.99 1.61h9.72a2 2 0 001.99-1.61L23 6H6"/></svg>
    </button>
    <button class="nav-icon-btn" title="Account">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
    </button>
    <a href="demo.html" class="btn btn-primary">Book a Demo</a>
    <button class="hamburger" aria-label="Menu">
      <span></span><span></span><span></span>
    </button>
  </div>
</nav>

<div class="mobile-menu">
  <div class="mobile-menu-panel">
    <span class="mobile-close">✕</span>
    <div class="mobile-nav" style="margin-top:2rem">
      <a href="index.html">Home</a>
      <a href="about.html">About</a>
      <a href="products.html">Products</a>
      <a href="training.html">Training</a>
      <a href="purchase.html">Pricing</a>
      <a href="demo.html">Book a Demo</a>
      <a href="contact.html">Contact</a>
    </div>
  </div>
</div>
`;

const FOOTER_HTML = `
<footer>
  <div class="footer-grid">
    <div class="footer-brand">
      <div class="nav-brand" style="margin-bottom:1rem">
        <div class="logo-icon"></div>
        <div class="brand-text">
          <span class="brand-name">IMS <span>GROUP</span></span>
          <span class="brand-sub">Integrated Management Systems</span>
        </div>
      </div>
      <p>IMS Group empowers Rwandan businesses with smart digital management systems and professional training to grow efficiently and sustainably.</p>
    </div>
    <div class="footer-col">
      <h4>Solutions</h4>
      <a href="product-details.html?id=bar">Bar Management</a>
      <a href="product-details.html?id=retail">Retail Systems</a>
      <a href="product-details.html?id=restaurant">Restaurant System</a>
      <a href="product-details.html?id=hotel">Hotel Management</a>
      <a href="product-details.html?id=pharmacy">Pharmacy System</a>
    </div>
    <div class="footer-col">
      <h4>Company</h4>
      <a href="about.html">About Us</a>
      <a href="training.html">Training</a>
      <a href="demo.html">Book a Demo</a>
      <a href="purchase.html">Pricing</a>
      <a href="contact.html">Contact</a>
    </div>
    <div class="footer-col">
      <h4>Contact</h4>
      <a href="tel:+250780000000">+250 780 000 000</a>
      <a href="mailto:info@imsgroup.rw">info@imsgroup.rw</a>
      <a href="#">Kigali, Rwanda</a>
      <a href="https://wa.me/250780000000" target="_blank">WhatsApp Chat</a>
    </div>
  </div>
  <div class="footer-bottom">
    <p>© 2025 IMS Group. All rights reserved. Kigali, Rwanda.</p>
    <p>Made with ❤️ for Rwandan businesses</p>
  </div>
</footer>

<a href="https://wa.me/250780000000" class="float-whatsapp" target="_blank" title="Chat on WhatsApp">
  <svg viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.890-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
</a>
`;

// Inject on DOM ready
document.addEventListener('DOMContentLoaded', () => {
  const navContainer = document.getElementById('nav-container');
  const footerContainer = document.getElementById('footer-container');
  if (navContainer) navContainer.innerHTML = NAV_HTML;
  if (footerContainer) footerContainer.innerHTML = FOOTER_HTML;
});
