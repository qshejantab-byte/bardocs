// IMS GROUP - MAIN JAVASCRIPT

// ---- Navbar scroll effect ----
const navbar = document.querySelector('.navbar');
if (navbar) {
  window.addEventListener('scroll', () => {
    navbar.classList.toggle('scrolled', window.scrollY > 20);
  });
}

// ---- Mobile Menu ----
const hamburger = document.querySelector('.hamburger');
const mobileMenu = document.querySelector('.mobile-menu');
const mobileClose = document.querySelector('.mobile-close');

if (hamburger && mobileMenu) {
  hamburger.addEventListener('click', () => mobileMenu.classList.add('open'));
  mobileClose?.addEventListener('click', () => mobileMenu.classList.remove('open'));
  mobileMenu.addEventListener('click', (e) => {
    if (e.target === mobileMenu) mobileMenu.classList.remove('open');
  });
}

// ---- Set active nav item ----
const currentPage = window.location.pathname.split('/').pop() || 'index.html';
document.querySelectorAll('.nav-item[data-page]').forEach(item => {
  if (item.dataset.page === currentPage) item.classList.add('active');
});

// ---- Payment method selector ----
document.querySelectorAll('.payment-method').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.payment-method').forEach(b => b.classList.remove('selected'));
    btn.classList.add('selected');
  });
});

// ---- Price option selector ----
document.querySelectorAll('.price-option').forEach(opt => {
  opt.addEventListener('click', () => {
    document.querySelectorAll('.price-option').forEach(o => o.classList.remove('selected'));
    opt.classList.add('selected');
  });
});

// ---- Form submission handler ----
document.querySelectorAll('.ims-form').forEach(form => {
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const btn = form.querySelector('[type="submit"]');
    const originalText = btn.innerHTML;
    btn.innerHTML = '⏳ Submitting...';
    btn.disabled = true;
    setTimeout(() => {
      btn.innerHTML = originalText;
      btn.disabled = false;
      form.reset();
      const msg = form.querySelector('.success-msg');
      if (msg) { msg.classList.add('show'); setTimeout(() => msg.classList.remove('show'), 5000); }
      document.querySelectorAll('.payment-method').forEach(b => b.classList.remove('selected'));
    }, 1500);
  });
});

// ---- Drag & Drop product image zone ----
const uploadZone = document.querySelector('.upload-zone');
if (uploadZone) {
  const fileInput = uploadZone.querySelector('input[type="file"]');

  uploadZone.addEventListener('click', () => fileInput?.click());

  uploadZone.addEventListener('dragover', (e) => { e.preventDefault(); uploadZone.classList.add('drag-over'); });
  uploadZone.addEventListener('dragleave', () => uploadZone.classList.remove('drag-over'));
  uploadZone.addEventListener('drop', (e) => {
    e.preventDefault();
    uploadZone.classList.remove('drag-over');
    const files = e.dataTransfer.files;
    if (files.length) handleProductUpload(files);
  });

  fileInput?.addEventListener('change', (e) => {
    if (e.target.files.length) handleProductUpload(e.target.files);
  });
}

function handleProductUpload(files) {
  const zone = document.querySelector('.upload-zone');
  const name = files[0].name;
  zone.innerHTML = `
    <div class="upload-icon">✅</div>
    <h3>${files.length} product image(s) uploaded</h3>
    <p>${name}${files.length > 1 ? ` and ${files.length - 1} more` : ''}</p>
    <button class="btn btn-secondary btn-sm" onclick="resetUpload()">Upload different files</button>
  `;
}

function resetUpload() {
  const zone = document.querySelector('.upload-zone');
  zone.innerHTML = `
    <input type="file" accept="image/*" multiple style="display:none">
    <div class="upload-icon">📦</div>
    <h3>Drop product images here</h3>
    <p>Drag & drop product screenshots or photos, or click to browse</p>
    <button class="btn btn-primary btn-sm" type="button">Choose Files</button>
  `;
  const newInput = zone.querySelector('input[type="file"]');
  zone.addEventListener('click', () => newInput?.click());
  newInput?.addEventListener('change', (e) => { if (e.target.files.length) handleProductUpload(e.target.files); });
}

// ---- Smooth scroll for anchor links ----
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', (e) => {
    const target = document.querySelector(a.getAttribute('href'));
    if (target) { e.preventDefault(); target.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
  });
});

// ---- Animate on scroll ----
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) entry.target.classList.add('visible');
  });
}, { threshold: 0.1 });

document.querySelectorAll('.feature-card, .product-card, .testimonial-card, .training-card, .value-item').forEach(el => {
  el.classList.add('fade-in');
  observer.observe(el);
});

// Inject fade-in CSS
const style = document.createElement('style');
style.textContent = `
  .fade-in { opacity: 0; transform: translateY(20px); transition: opacity 0.5s ease, transform 0.5s ease; }
  .fade-in.visible { opacity: 1; transform: translateY(0); }
`;
document.head.appendChild(style);
