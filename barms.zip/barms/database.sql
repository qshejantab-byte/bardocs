-- ============================================================
--  BarMS Pro — MySQL Database Schema
--  Run this file once in phpMyAdmin or MySQL CLI to set up
--  the database for one bar client.
--
--  Usage:
--    1. Open phpMyAdmin on cPanel
--    2. Create a new database (e.g. chezpatrick_db)
--    3. Select that database
--    4. Click "Import" and upload this file
--    Done!
-- ============================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+02:00"; -- Kigali timezone (CAT)

-- ─────────────────────────────────────────────────────────────
-- TABLE: users
-- Stores all system users (Owner, Manager, Bartender)
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `users` (
  `id`         INT AUTO_INCREMENT PRIMARY KEY,
  `full_name`  VARCHAR(100) NOT NULL,
  `username`   VARCHAR(50)  NOT NULL UNIQUE,
  `password`   VARCHAR(255) NOT NULL COMMENT 'bcrypt hashed',
  `role`       ENUM('Owner','Manager','Bartender') NOT NULL DEFAULT 'Bartender',
  `active`     TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─────────────────────────────────────────────────────────────
-- TABLE: settings
-- One row per bar — bar name, location, currency
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `settings` (
  `id`          INT AUTO_INCREMENT PRIMARY KEY,
  `bar_name`    VARCHAR(100) NOT NULL DEFAULT 'BarMS Pro',
  `location`    VARCHAR(100) NOT NULL DEFAULT 'Kigali, Rwanda',
  `currency`    VARCHAR(10)  NOT NULL DEFAULT 'RWF',
  `updated_at`  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─────────────────────────────────────────────────────────────
-- TABLE: products
-- Drinks, food items, and other sellable items
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `products` (
  `id`          INT AUTO_INCREMENT PRIMARY KEY,
  `name`        VARCHAR(100) NOT NULL,
  `category`    VARCHAR(50)  NOT NULL DEFAULT 'General',
  `unit`        VARCHAR(30)  NOT NULL DEFAULT 'Unit',
  `sell_price`  DECIMAL(12,2) NOT NULL DEFAULT 0,
  `cost_price`  DECIMAL(12,2) NOT NULL DEFAULT 0,
  `stock`       INT NOT NULL DEFAULT 0,
  `alert_level` INT NOT NULL DEFAULT 5 COMMENT 'Low stock warning threshold',
  `active`      TINYINT(1) NOT NULL DEFAULT 1,
  `created_at`  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─────────────────────────────────────────────────────────────
-- TABLE: sales
-- Every sale transaction recorded by bartenders/managers
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `sales` (
  `id`           INT AUTO_INCREMENT PRIMARY KEY,
  `product_id`   INT NOT NULL,
  `product_name` VARCHAR(100) NOT NULL,
  `qty`          INT NOT NULL DEFAULT 1,
  `unit_price`   DECIMAL(12,2) NOT NULL,
  `total`        DECIMAL(12,2) NOT NULL,
  `sold_by`      VARCHAR(100) NOT NULL,
  `sale_date`    DATE NOT NULL,
  `sale_time`    TIME NOT NULL,
  `voided`       TINYINT(1) NOT NULL DEFAULT 0,
  `created_at`   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─────────────────────────────────────────────────────────────
-- TABLE: stock_movements
-- Every stock IN/OUT movement (restocking, sales, adjustments)
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `stock_movements` (
  `id`           INT AUTO_INCREMENT PRIMARY KEY,
  `product_id`   INT NOT NULL,
  `product_name` VARCHAR(100) NOT NULL,
  `type`         ENUM('IN','OUT') NOT NULL,
  `qty`          INT NOT NULL,
  `note`         VARCHAR(255),
  `move_date`    DATE NOT NULL,
  `moved_by`     VARCHAR(100) NOT NULL,
  `created_at`   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─────────────────────────────────────────────────────────────
-- TABLE: expenses
-- Bar operational expenses (utilities, cleaning, etc.)
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `expenses` (
  `id`           INT AUTO_INCREMENT PRIMARY KEY,
  `description`  VARCHAR(255) NOT NULL,
  `category`     VARCHAR(50) NOT NULL DEFAULT 'General',
  `amount`       DECIMAL(12,2) NOT NULL,
  `expense_date` DATE NOT NULL,
  `recorded_by`  VARCHAR(100) NOT NULL,
  `voided`       TINYINT(1) NOT NULL DEFAULT 0,
  `created_at`   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─────────────────────────────────────────────────────────────
-- TABLE: employees
-- Staff records (not system users — these are payroll records)
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `employees` (
  `id`         INT AUTO_INCREMENT PRIMARY KEY,
  `full_name`  VARCHAR(100) NOT NULL,
  `position`   VARCHAR(80) NOT NULL,
  `phone`      VARCHAR(20),
  `salary`     DECIMAL(12,2) NOT NULL DEFAULT 0,
  `hire_date`  DATE NOT NULL,
  `active`     TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─────────────────────────────────────────────────────────────
-- TABLE: employee_debts
-- Staff salary advances / debts
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `employee_debts` (
  `id`          INT AUTO_INCREMENT PRIMARY KEY,
  `employee_id` INT NOT NULL,
  `emp_name`    VARCHAR(100) NOT NULL,
  `amount`      DECIMAL(12,2) NOT NULL,
  `note`        VARCHAR(255) DEFAULT 'Advance',
  `debt_date`   DATE NOT NULL,
  `status`      ENUM('Pending','Paid') NOT NULL DEFAULT 'Pending',
  `created_at`  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─────────────────────────────────────────────────────────────
-- TABLE: salary_payments
-- Salary payment history with debt deductions
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `salary_payments` (
  `id`             INT AUTO_INCREMENT PRIMARY KEY,
  `employee_id`    INT NOT NULL,
  `emp_name`       VARCHAR(100) NOT NULL,
  `gross_amount`   DECIMAL(12,2) NOT NULL,
  `deducted_debt`  DECIMAL(12,2) NOT NULL DEFAULT 0,
  `net_amount`     DECIMAL(12,2) NOT NULL,
  `note`           VARCHAR(255),
  `payment_date`   DATE NOT NULL,
  `created_at`     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─────────────────────────────────────────────────────────────
-- TABLE: kitchen_revenue
-- Kitchen-specific revenue entries (separate from bar)
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `kitchen_revenue` (
  `id`           INT AUTO_INCREMENT PRIMARY KEY,
  `amount`       DECIMAL(12,2) NOT NULL,
  `note`         VARCHAR(255) DEFAULT 'Daily revenue',
  `revenue_date` DATE NOT NULL,
  `recorded_by`  VARCHAR(100) NOT NULL,
  `created_at`   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─────────────────────────────────────────────────────────────
-- TABLE: kitchen_expenses
-- Kitchen-specific expenses (ingredients, gas, etc.)
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `kitchen_expenses` (
  `id`           INT AUTO_INCREMENT PRIMARY KEY,
  `description`  VARCHAR(255) NOT NULL,
  `category`     VARCHAR(50) NOT NULL DEFAULT 'General',
  `amount`       DECIMAL(12,2) NOT NULL,
  `expense_date` DATE NOT NULL,
  `recorded_by`  VARCHAR(100) NOT NULL,
  `created_at`   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─────────────────────────────────────────────────────────────
-- TABLE: customer_debts
-- Customer unpaid balances / tabs
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `customer_debts` (
  `id`           INT AUTO_INCREMENT PRIMARY KEY,
  `customer_name` VARCHAR(100) NOT NULL,
  `phone`        VARCHAR(20),
  `amount`       DECIMAL(12,2) NOT NULL,
  `note`         VARCHAR(255),
  `debt_date`    DATE NOT NULL,
  `status`       ENUM('Pending','Paid') NOT NULL DEFAULT 'Pending',
  `recorded_by`  VARCHAR(100) NOT NULL,
  `created_at`   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─────────────────────────────────────────────────────────────
-- TABLE: void_requests
-- Manager requests to Owner for voiding sales/expenses
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `void_requests` (
  `id`           INT AUTO_INCREMENT PRIMARY KEY,
  `type`         VARCHAR(30) NOT NULL COMMENT 'sale, expense, kitrev',
  `ref_id`       INT NOT NULL,
  `label`        VARCHAR(255) NOT NULL,
  `amount`       DECIMAL(12,2) NOT NULL,
  `reason`       TEXT,
  `requested_by` VARCHAR(100) NOT NULL,
  `status`       ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
  `reviewed_by`  VARCHAR(100),
  `created_at`   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `reviewed_at`  TIMESTAMP NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─────────────────────────────────────────────────────────────
-- TABLE: audit_log
-- Full audit trail of all actions in the system
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `audit_log` (
  `id`          INT AUTO_INCREMENT PRIMARY KEY,
  `action_type` VARCHAR(50) NOT NULL,
  `details`     TEXT,
  `done_by`     VARCHAR(100) NOT NULL,
  `done_at`     TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─────────────────────────────────────────────────────────────
-- TABLE: notifications
-- System notifications (low stock, reports, etc.)
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `notifications` (
  `id`          INT AUTO_INCREMENT PRIMARY KEY,
  `message`     VARCHAR(255) NOT NULL,
  `type`        ENUM('info','warning','success','error') NOT NULL DEFAULT 'info',
  `is_read`     TINYINT(1) NOT NULL DEFAULT 0,
  `created_at`  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─────────────────────────────────────────────────────────────
-- TABLE: mgr_permissions
-- Owner-controlled permissions for Manager role
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `mgr_permissions` (
  `id`                  INT AUTO_INCREMENT PRIMARY KEY,
  `can_view_reports`    TINYINT(1) NOT NULL DEFAULT 1,
  `can_edit_stock`      TINYINT(1) NOT NULL DEFAULT 1,
  `can_edit_products`   TINYINT(1) NOT NULL DEFAULT 1,
  `can_view_employees`  TINYINT(1) NOT NULL DEFAULT 1,
  `can_view_audit`      TINYINT(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- SEED DATA — Default data on first install
-- ============================================================

-- Default owner user (password: system123)
INSERT INTO `users` (`full_name`, `username`, `password`, `role`) VALUES
('Bar Owner', 'owner', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Owner');
-- NOTE: Default password is "system123" — client must change on first login
-- The hash above is bcrypt of "system123"

-- Default settings
INSERT INTO `settings` (`bar_name`, `location`, `currency`) VALUES
('BarMS Pro', 'Kigali, Rwanda', 'RWF');

-- Default manager permissions
INSERT INTO `mgr_permissions` (`can_view_reports`,`can_edit_stock`,`can_edit_products`,`can_view_employees`,`can_view_audit`) VALUES
(1, 1, 1, 1, 0);

-- Sample products
INSERT INTO `products` (`name`, `category`, `unit`, `sell_price`, `cost_price`, `stock`, `alert_level`) VALUES
('Primus Beer',         'Beer',       'Bottle', 1500,  900,  120, 20),
('Heineken',            'Beer',       'Bottle', 2000, 1200,   80, 15),
('Fanta Orange',        'Soft Drink', 'Bottle',  800,  450,   60, 10),
('Nyama Choma',         'Food',       'Plate',  8000, 4500,   30,  5),
('Brochettes',          'Food',       'Plate',  3500, 2000,   40,  8),
('Urwagwa',             'Drinks',     'Glass',  1200,  600,   50, 10),
('Isombe & Ubugali',    'Food',       'Plate',  3000, 1500,   25,  5),
('Johnnie Walker Red',  'Spirits',    'Shot',   4500, 2800,    7, 10);
