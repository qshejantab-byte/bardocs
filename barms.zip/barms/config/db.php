<?php
// ============================================================
//  BarMS Pro — Database Configuration
//  config/db.php
// ============================================================

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'barms_db');
define('SESSION_SECRET', 'barms_secret_2024');

// ── Start session only if not already started ─────────────────
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 86400,
        'path'     => '/',
        'domain'   => '',
        'secure'   => false,
        'httponly'  => false,
        'samesite' => 'Lax'
    ]);
    session_start();
}

// ── Suppress notices ──────────────────────────────────────────
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);

// ── Database connection ───────────────────────────────────────
function getDB() {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                ]
            );
        } catch (PDOException $e) {
            header('Content-Type: application/json');
            http_response_code(500);
            die(json_encode(['ok' => false, 'error' => 'DB connection failed: ' . $e->getMessage()]));
        }
    }
    return $pdo;
}

// ── JSON output ───────────────────────────────────────────────
function jsonOut($data, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

// ── Auth check ────────────────────────────────────────────────
function requireAuth() {
    if (empty($_SESSION['user_id'])) {
        jsonOut(['ok' => false, 'error' => 'Not authenticated'], 401);
    }
    return $_SESSION;
}

function requireRole($roles) {
    $sess = requireAuth();
    if (!in_array($sess['role'], (array)$roles)) {
        jsonOut(['ok' => false, 'error' => 'Access denied'], 403);
    }
    return $sess;
}

// ── CORS headers ──────────────────────────────────────────────
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
if ($origin) {
    header('Access-Control-Allow-Origin: ' . $origin);
    header('Access-Control-Allow-Credentials: true');
} else {
    header('Access-Control-Allow-Origin: *');
}
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit(0); }
