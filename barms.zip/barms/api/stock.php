<?php
// ============================================================
//  api/stock.php — Stock movements
//  GET  action=list
//  POST action=record { productId, type, qty, cost, note }
// ============================================================
require_once __DIR__ . '/../config/db.php';


$action = $_REQUEST['action'] ?? 'list';
$db     = getDB();

if ($action === 'list') {
    requireAuth();
    $stmt = $db->query('SELECT * FROM stock_movements ORDER BY id DESC');
    $rows = $stmt->fetchAll();
    foreach ($rows as &$r) {
        $r['id'] = (int)$r['id'];
        $r['product_id'] = (int)$r['product_id'];
        $r['qty'] = (int)$r['qty'];
        $r['productId'] = $r['product_id'];
        $r['productName'] = $r['product_name'];
        $r['date'] = $r['move_date'];
        $r['by'] = $r['moved_by'];
    }
    jsonOut(['ok' => true, 'data' => $rows]);
}

if ($action === 'record') {
    requireRole(['Owner', 'Manager']);
    $sess = $_SESSION;
    $body = json_decode(file_get_contents('php://input'), true);

    $productId = (int)($body['productId'] ?? 0);
    $type      = $body['type'] ?? 'IN';
    $qty       = (int)($body['qty'] ?? 0);
    $cost      = (float)($body['cost'] ?? 0);
    $note      = trim($body['note'] ?? $type);

    if (!$productId || $qty < 1) jsonOut(['ok' => false, 'error' => 'Invalid data'], 400);

    $stmt = $db->prepare('SELECT * FROM products WHERE id = ?');
    $stmt->execute([$productId]);
    $product = $stmt->fetch();
    if (!$product) jsonOut(['ok' => false, 'error' => 'Product not found'], 404);

    if ($type === 'OUT' && $product['stock'] < $qty) {
        jsonOut(['ok' => false, 'error' => "Only {$product['stock']} in stock"], 400);
    }

    $db->beginTransaction();
    try {
        if ($type === 'IN') {
            $costUpdate = $cost > 0 ? ', cost_price = ?' : '';
            $params = $cost > 0 ? [$qty, $cost, $productId] : [$qty, $productId];
            $db->prepare("UPDATE products SET stock = stock + ? $costUpdate WHERE id = ?")->execute($params);
        } else {
            $db->prepare('UPDATE products SET stock = stock - ? WHERE id = ?')->execute([$qty, $productId]);
        }

        $db->prepare('INSERT INTO stock_movements (product_id, product_name, type, qty, note, move_date, moved_by) VALUES (?,?,?,?,?,?,?)')
           ->execute([$productId, $product['name'], $type, $qty, $note, date('Y-m-d'), $sess['full_name']]);

        $db->prepare('INSERT INTO audit_log (action_type, details, done_by) VALUES (?,?,?)')
           ->execute(['STOCK', "Stock $type: {$qty}× {$product['name']}. Note: $note", $sess['full_name']]);

        $db->commit();
        jsonOut(['ok' => true]);
    } catch (Exception $e) {
        $db->rollBack();
        jsonOut(['ok' => false, 'error' => $e->getMessage()], 500);
    }
}

jsonOut(['ok' => false, 'error' => 'Unknown action'], 400);
