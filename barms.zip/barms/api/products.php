<?php
// ============================================================
//  api/products.php
//  GET    action=list              → all products
//  POST   action=save              → add/update product
//  POST   action=deactivate        → soft-delete product
//  POST   action=request_price_change → manager price change request
// ============================================================
require_once __DIR__ . '/../config/db.php';


$action = $_REQUEST['action'] ?? 'list';
$db     = getDB();

// ── LIST ──────────────────────────────────────────────────────
if ($action === 'list') {
    requireAuth();
    $stmt = $db->query('SELECT * FROM products ORDER BY active DESC, name ASC');
    $rows = $stmt->fetchAll();
    // Normalise types for JS
    foreach ($rows as &$r) {
        $r['id']          = (int)$r['id'];
        $r['sell_price']  = (float)$r['sell_price'];
        $r['cost_price']  = (float)$r['cost_price'];
        $r['stock']       = (int)$r['stock'];
        $r['alert_level'] = (int)$r['alert_level'];
        $r['active']      = (bool)$r['active'];
        // JS-compatible aliases
        $r['sellPrice']   = $r['sell_price'];
        $r['costPrice']   = $r['cost_price'];
        $r['alert']       = $r['alert_level'];
    }
    jsonOut(['ok' => true, 'data' => $rows]);
}

// ── SAVE (add or update) ──────────────────────────────────────
if ($action === 'save') {
    requireRole(['Owner']);
    $body = json_decode(file_get_contents('php://input'), true);

    $id        = (int)($body['id'] ?? 0);
    $name      = trim($body['name'] ?? '');
    $category  = trim($body['category'] ?? 'General');
    $unit      = trim($body['unit'] ?? 'Unit');
    $sellPrice = (float)($body['sellPrice'] ?? 0);
    $costPrice = (float)($body['costPrice'] ?? 0);
    $stock     = (int)($body['stock'] ?? 0);
    $alert     = (int)($body['alert'] ?? 5);

    if (!$name) jsonOut(['ok' => false, 'error' => 'Product name required'], 400);

    if ($id > 0) {
        $db->prepare('UPDATE products SET name=?, category=?, unit=?, sell_price=?, cost_price=?, stock=?, alert_level=? WHERE id=?')
           ->execute([$name, $category, $unit, $sellPrice, $costPrice, $stock, $alert, $id]);
        $sess = $_SESSION;
        $db->prepare('INSERT INTO audit_log (action_type, details, done_by) VALUES (?,?,?)')
           ->execute(['PRODUCT', "Updated product: $name", $sess['full_name']]);
    } else {
        $db->prepare('INSERT INTO products (name, category, unit, sell_price, cost_price, stock, alert_level) VALUES (?,?,?,?,?,?,?)')
           ->execute([$name, $category, $unit, $sellPrice, $costPrice, $stock, $alert]);
        $id = (int)$db->lastInsertId();
        $sess = $_SESSION;
        $db->prepare('INSERT INTO audit_log (action_type, details, done_by) VALUES (?,?,?)')
           ->execute(['PRODUCT', "Added product: $name at $sellPrice", $sess['full_name']]);
    }

    jsonOut(['ok' => true, 'id' => $id]);
}

// ── DEACTIVATE ────────────────────────────────────────────────
if ($action === 'deactivate') {
    requireRole(['Owner']);
    $body = json_decode(file_get_contents('php://input'), true);
    $id   = (int)($body['id'] ?? 0);
    if (!$id) jsonOut(['ok' => false, 'error' => 'Invalid id'], 400);
    $db->prepare('UPDATE products SET active = 0 WHERE id = ?')->execute([$id]);
    jsonOut(['ok' => true]);
}

// ── UPDATE PRICE (direct, Owner only) ────────────────────────
if ($action === 'update_price') {
    requireRole(['Owner']);
    $body  = json_decode(file_get_contents('php://input'), true);
    $id    = (int)($body['id'] ?? 0);
    $price = (float)($body['price'] ?? 0);
    if (!$id || $price <= 0) jsonOut(['ok' => false, 'error' => 'Invalid data'], 400);
    $db->prepare('UPDATE products SET sell_price = ? WHERE id = ?')->execute([$price, $id]);
    $db->prepare('INSERT INTO audit_log (action_type, details, done_by) VALUES (?,?,?)')
       ->execute(['PRODUCT', "Price updated for product #$id to $price", $_SESSION['full_name']]);
    jsonOut(['ok' => true]);
}

jsonOut(['ok' => false, 'error' => 'Unknown action'], 400);
