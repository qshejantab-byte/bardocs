<?php
// ============================================================
//  api/expenses.php
//  GET  action=list
//  POST action=save   { desc, category, amount, date }
//  POST action=void   { id }  Owner only
// ============================================================
require_once __DIR__ . '/../config/db.php';


$action = $_REQUEST['action'] ?? 'list';
$db     = getDB();

if ($action === 'list') {
    requireAuth();
    $stmt = $db->query('SELECT * FROM expenses ORDER BY id DESC');
    $rows = $stmt->fetchAll();
    foreach ($rows as &$r) {
        $r['id']     = (int)$r['id'];
        $r['amount'] = (float)$r['amount'];
        $r['voided'] = (bool)$r['voided'];
        $r['desc']   = $r['description'];
        $r['date']   = $r['expense_date'];
        $r['by']     = $r['recorded_by'];
    }
    jsonOut(['ok' => true, 'data' => $rows]);
}

if ($action === 'save') {
    requireRole(['Owner', 'Manager']);
    $sess = $_SESSION;
    $body = json_decode(file_get_contents('php://input'), true);

    $desc     = trim($body['desc'] ?? '');
    $category = trim($body['category'] ?? 'General');
    $amount   = (float)($body['amount'] ?? 0);
    $date     = $body['date'] ?? date('Y-m-d');

    if (!$desc || $amount <= 0) jsonOut(['ok' => false, 'error' => 'Description and amount required'], 400);

    $db->prepare('INSERT INTO expenses (description, category, amount, expense_date, recorded_by) VALUES (?,?,?,?,?)')
       ->execute([$desc, $category, $amount, $date, $sess['full_name']]);
    $id = (int)$db->lastInsertId();

    $db->prepare('INSERT INTO audit_log (action_type, details, done_by) VALUES (?,?,?)')
       ->execute(['EXPENSE', "Recorded expense: $desc — RWF $amount ($category)", $sess['full_name']]);

    jsonOut(['ok' => true, 'id' => $id]);
}

if ($action === 'void') {
    requireRole(['Owner']);
    $body = json_decode(file_get_contents('php://input'), true);
    $id   = (int)($body['id'] ?? 0);
    if (!$id) jsonOut(['ok' => false, 'error' => 'Invalid id'], 400);
    $db->prepare('UPDATE expenses SET voided = 1 WHERE id = ?')->execute([$id]);
    $db->prepare('INSERT INTO audit_log (action_type, details, done_by) VALUES (?,?,?)')
       ->execute(['VOID', "Voided expense #$id", $_SESSION['full_name']]);
    jsonOut(['ok' => true]);
}

jsonOut(['ok' => false, 'error' => 'Unknown action'], 400);
