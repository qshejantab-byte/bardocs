<?php
// ============================================================
//  api/employees.php — Staff, Employee Debts, Salary
//  GET  action=list
//  POST action=save        { id?, fullName, position, phone, salary }
//  POST action=debt_save   { empId, amount, note }
//  GET  action=debt_list
//  POST action=debt_paid   { id }
//  POST action=salary_pay  { empId, amount, note }
//  GET  action=salary_list
// ============================================================
require_once __DIR__ . '/../config/db.php';


$action = $_REQUEST['action'] ?? 'list';
$db     = getDB();

// ── LIST EMPLOYEES ────────────────────────────────────────────
if ($action === 'list') {
    requireAuth();
    $stmt = $db->query('SELECT * FROM employees WHERE active = 1 ORDER BY full_name ASC');
    $rows = $stmt->fetchAll();
    foreach ($rows as &$r) {
        $r['id']       = (int)$r['id'];
        $r['salary']   = (float)$r['salary'];
        $r['active']   = (bool)$r['active'];
        $r['fullName'] = $r['full_name'];
        $r['hireDate'] = $r['hire_date'];
    }
    jsonOut(['ok' => true, 'data' => $rows]);
}

// ── SAVE EMPLOYEE ─────────────────────────────────────────────
if ($action === 'save') {
    requireRole(['Owner', 'Manager']);
    $sess = $_SESSION;
    $body = json_decode(file_get_contents('php://input'), true);

    $id       = (int)($body['id'] ?? 0);
    $fullName = trim($body['fullName'] ?? '');
    $position = trim($body['position'] ?? '');
    $phone    = trim($body['phone'] ?? '');
    $salary   = (float)($body['salary'] ?? 0);

    if (!$fullName) jsonOut(['ok' => false, 'error' => 'Name required'], 400);

    if ($id > 0) {
        $db->prepare('UPDATE employees SET full_name=?, position=?, phone=?, salary=? WHERE id=?')
           ->execute([$fullName, $position, $phone, $salary, $id]);
        jsonOut(['ok' => true, 'id' => $id]);
    } else {
        $db->prepare('INSERT INTO employees (full_name, position, phone, salary, hire_date) VALUES (?,?,?,?,?)')
           ->execute([$fullName, $position, $phone, $salary, date('Y-m-d')]);
        jsonOut(['ok' => true, 'id' => (int)$db->lastInsertId()]);
    }
}

// ── LIST EMPLOYEE DEBTS ───────────────────────────────────────
if ($action === 'debt_list') {
    requireAuth();
    $stmt = $db->query('SELECT * FROM employee_debts ORDER BY id DESC');
    $rows = $stmt->fetchAll();
    foreach ($rows as &$r) {
        $r['id']         = (int)$r['id'];
        $r['employee_id']= (int)$r['employee_id'];
        $r['amount']     = (float)$r['amount'];
        $r['empId']      = $r['employee_id'];
        $r['empName']    = $r['emp_name'];
        $r['date']       = $r['debt_date'];
    }
    jsonOut(['ok' => true, 'data' => $rows]);
}

// ── SAVE DEBT ─────────────────────────────────────────────────
if ($action === 'debt_save') {
    requireRole(['Owner', 'Manager']);
    $sess = $_SESSION;
    $body = json_decode(file_get_contents('php://input'), true);

    $empId  = (int)($body['empId'] ?? 0);
    $amount = (float)($body['amount'] ?? 0);
    $note   = trim($body['note'] ?? 'Advance');

    if (!$empId || $amount <= 0) jsonOut(['ok' => false, 'error' => 'Invalid data'], 400);

    $stmt = $db->prepare('SELECT full_name FROM employees WHERE id = ?');
    $stmt->execute([$empId]);
    $emp = $stmt->fetch();
    if (!$emp) jsonOut(['ok' => false, 'error' => 'Employee not found'], 404);

    $db->prepare('INSERT INTO employee_debts (employee_id, emp_name, amount, note, debt_date) VALUES (?,?,?,?,?)')
       ->execute([$empId, $emp['full_name'], $amount, $note, date('Y-m-d')]);

    jsonOut(['ok' => true, 'id' => (int)$db->lastInsertId()]);
}

// ── MARK DEBT PAID ────────────────────────────────────────────
if ($action === 'debt_paid') {
    requireRole(['Owner', 'Manager']);
    $body = json_decode(file_get_contents('php://input'), true);
    $id   = (int)($body['id'] ?? 0);
    if (!$id) jsonOut(['ok' => false, 'error' => 'Invalid id'], 400);
    $db->prepare("UPDATE employee_debts SET status='Paid' WHERE id=?")->execute([$id]);
    jsonOut(['ok' => true]);
}

// ── PAY SALARY ────────────────────────────────────────────────
if ($action === 'salary_pay') {
    requireRole(['Owner']);
    $sess = $_SESSION;
    $body = json_decode(file_get_contents('php://input'), true);

    $empId = (int)($body['empId'] ?? 0);
    $gross = (float)($body['amount'] ?? 0);
    $note  = trim($body['note'] ?? 'Salary payment');

    if (!$empId || $gross <= 0) jsonOut(['ok' => false, 'error' => 'Invalid data'], 400);

    $stmt = $db->prepare('SELECT full_name FROM employees WHERE id = ?');
    $stmt->execute([$empId]);
    $emp = $stmt->fetch();
    if (!$emp) jsonOut(['ok' => false, 'error' => 'Employee not found'], 404);

    // Get unpaid debts
    $dStmt = $db->prepare("SELECT SUM(amount) AS total FROM employee_debts WHERE employee_id=? AND status='Pending'");
    $dStmt->execute([$empId]);
    $debtTotal = (float)($dStmt->fetch()['total'] ?? 0);
    $netPay    = max(0, $gross - $debtTotal);

    $db->beginTransaction();
    try {
        $db->prepare('INSERT INTO salary_payments (employee_id, emp_name, gross_amount, deducted_debt, net_amount, note, payment_date) VALUES (?,?,?,?,?,?,?)')
           ->execute([$empId, $emp['full_name'], $gross, $debtTotal, $netPay, $note, date('Y-m-d')]);

        if ($debtTotal > 0) {
            $db->prepare("UPDATE employee_debts SET status='Paid' WHERE employee_id=? AND status='Pending'")->execute([$empId]);
        }

        $db->prepare('INSERT INTO audit_log (action_type, details, done_by) VALUES (?,?,?)')
           ->execute(['SALARY', "Paid salary to {$emp['full_name']}: Gross RWF $gross, Deductions RWF $debtTotal, Net RWF $netPay", $sess['full_name']]);

        $db->commit();
        jsonOut(['ok' => true, 'netPay' => $netPay, 'debtTotal' => $debtTotal]);
    } catch (Exception $e) {
        $db->rollBack();
        jsonOut(['ok' => false, 'error' => $e->getMessage()], 500);
    }
}

// ── SALARY HISTORY ────────────────────────────────────────────
if ($action === 'salary_list') {
    requireAuth();
    $stmt = $db->query('SELECT * FROM salary_payments ORDER BY id DESC');
    $rows = $stmt->fetchAll();
    foreach ($rows as &$r) {
        $r['id']           = (int)$r['id'];
        $r['employee_id']  = (int)$r['employee_id'];
        $r['gross_amount'] = (float)$r['gross_amount'];
        $r['deducted_debt']= (float)$r['deducted_debt'];
        $r['net_amount']   = (float)$r['net_amount'];
        $r['empName']      = $r['emp_name'];
        $r['amount']       = $r['net_amount'];
        $r['deductedDebt'] = $r['deducted_debt'];
        $r['date']         = $r['payment_date'];
    }
    jsonOut(['ok' => true, 'data' => $rows]);
}

jsonOut(['ok' => false, 'error' => 'Unknown action'], 400);
