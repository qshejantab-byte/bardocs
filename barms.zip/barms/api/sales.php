<?php
// ============================================================
//  api/sales.php
//  GET  action=list   ?filter=today|week|month|date&date=YYYY-MM-DD
//  POST action=record  { productId, qty }
//  POST action=quick   { items:[{id,qty},...] }  — Quick Sale
//  POST action=void    { id }  — Owner only
//  POST action=request_void { id, reason } — Manager
// ============================================================
require_once __DIR__ . '/../config/db.php';


$action = $_REQUEST['action'] ?? 'list';
$db     = getDB();

// ── LIST ──────────────────────────────────────────────────────
if ($action === 'list') {
    $sess   = requireAuth();
    $filter = $_GET['filter'] ?? 'today';
    $date   = $_GET['date']   ?? date('Y-m-d');

    if ($filter === 'date') {
        $where = 'sale_date = ?'; $params = [$date];
    } elseif ($filter === 'week') {
        $where = 'sale_date >= ?'; $params = [date('Y-m-d', strtotime('-7 days'))];
    } elseif ($filter === 'month') {
        $where = 'sale_date LIKE ?'; $params = [date('Y-m') . '%'];
    } else { // today
        $where = 'sale_date = ?'; $params = [date('Y-m-d')];
    }

    // Bartenders only see their own sales
    if ($sess['role'] === 'Bartender') {
        $where   .= ' AND sold_by = ?';
        $params[] = $sess['full_name'];
    }

    $stmt = $db->prepare("SELECT s.*, p.category FROM sales s LEFT JOIN products p ON s.product_id=p.id WHERE $where ORDER BY s.id DESC");
    $stmt->execute($params);
    $rows = $stmt->fetchAll();
    foreach ($rows as &$r) {
        $r['id']         = (int)$r['id'];
        $r['product_id'] = (int)$r['product_id'];
        $r['qty']        = (int)$r['qty'];
        $r['unit_price'] = (float)$r['unit_price'];
        $r['total']      = (float)$r['total'];
        $r['voided']     = (bool)$r['voided'];
        // JS aliases
        $r['productId']   = $r['product_id'];
        $r['productName'] = $r['product_name'];
        $r['unitPrice']   = $r['unit_price'];
        $r['soldBy']      = $r['sold_by'];
        $r['date']        = $r['sale_date'];
        $r['time']        = substr($r['sale_time'], 0, 5);
        $r['category']    = $r['category'] ?? 'General';
    }
    jsonOut(['ok' => true, 'data' => $rows]);
}

// ── RECORD SINGLE SALE ────────────────────────────────────────
if ($action === 'record') {
    $sess = requireAuth();
    $body = json_decode(file_get_contents('php://input'), true);

    $productId = (int)($body['productId'] ?? 0);
    $qty       = (int)($body['qty'] ?? 0);
    if (!$productId || $qty < 1) jsonOut(['ok' => false, 'error' => 'Invalid data'], 400);

    // Fetch product
    $stmt = $db->prepare('SELECT * FROM products WHERE id = ? AND active = 1');
    $stmt->execute([$productId]);
    $product = $stmt->fetch();
    if (!$product) jsonOut(['ok' => false, 'error' => 'Product not found'], 404);
    if ($product['stock'] < $qty) jsonOut(['ok' => false, 'error' => "Only {$product['stock']} in stock"], 400);

    $total    = $product['sell_price'] * $qty;
    $saleDate = date('Y-m-d');
    $saleTime = date('H:i:s');

    $db->beginTransaction();
    try {
        // Insert sale
        $db->prepare('INSERT INTO sales (product_id, product_name, qty, unit_price, total, sold_by, sale_date, sale_time) VALUES (?,?,?,?,?,?,?,?)')
           ->execute([$productId, $product['name'], $qty, $product['sell_price'], $total, $sess['full_name'], $saleDate, $saleTime]);
        $saleId = (int)$db->lastInsertId();

        // Deduct stock
        $db->prepare('UPDATE products SET stock = stock - ? WHERE id = ?')->execute([$qty, $productId]);

        // Stock movement
        $db->prepare('INSERT INTO stock_movements (product_id, product_name, type, qty, note, move_date, moved_by) VALUES (?,?,?,?,?,?,?)')
           ->execute([$productId, $product['name'], 'OUT', $qty, 'Sale', $saleDate, $sess['full_name']]);

        // Audit
        $db->prepare('INSERT INTO audit_log (action_type, details, done_by) VALUES (?,?,?)')
           ->execute(['SALE', "Sold {$qty}× {$product['name']} for RWF $total", $sess['full_name']]);

        $db->commit();
        jsonOut(['ok' => true, 'id' => $saleId, 'total' => $total]);
    } catch (Exception $e) {
        $db->rollBack();
        jsonOut(['ok' => false, 'error' => $e->getMessage()], 500);
    }
}

// ── QUICK SALE (multi-item) ───────────────────────────────────
if ($action === 'quick') {
    $sess  = requireAuth();
    $body  = json_decode(file_get_contents('php://input'), true);
    $items = $body['items'] ?? [];
    if (empty($items)) jsonOut(['ok' => false, 'error' => 'No items'], 400);

    $db->beginTransaction();
    try {
        $grandTotal = 0;
        $saleDate   = date('Y-m-d');
        $saleTime   = date('H:i:s');

        foreach ($items as $item) {
            $productId = (int)($item['id'] ?? 0);
            $qty       = (int)($item['qty'] ?? 0);
            if (!$productId || $qty < 1) continue;

            $stmt = $db->prepare('SELECT * FROM products WHERE id = ? AND active = 1');
            $stmt->execute([$productId]);
            $product = $stmt->fetch();
            if (!$product || $product['stock'] < $qty) {
                $db->rollBack();
                jsonOut(['ok' => false, 'error' => "Insufficient stock for: {$product['name']}"], 400);
            }

            $total = $product['sell_price'] * $qty;
            $grandTotal += $total;

            $db->prepare('INSERT INTO sales (product_id, product_name, qty, unit_price, total, sold_by, sale_date, sale_time) VALUES (?,?,?,?,?,?,?,?)')
               ->execute([$productId, $product['name'], $qty, $product['sell_price'], $total, $sess['full_name'], $saleDate, $saleTime]);

            $db->prepare('UPDATE products SET stock = stock - ? WHERE id = ?')->execute([$qty, $productId]);

            $db->prepare('INSERT INTO stock_movements (product_id, product_name, type, qty, note, move_date, moved_by) VALUES (?,?,?,?,?,?,?)')
               ->execute([$productId, $product['name'], 'OUT', $qty, 'Quick Sale', $saleDate, $sess['full_name']]);
        }

        $db->prepare('INSERT INTO audit_log (action_type, details, done_by) VALUES (?,?,?)')
           ->execute(['SALE', "Quick sale: " . count($items) . " items, total RWF $grandTotal", $sess['full_name']]);

        $db->commit();
        jsonOut(['ok' => true, 'total' => $grandTotal]);
    } catch (Exception $e) {
        $db->rollBack();
        jsonOut(['ok' => false, 'error' => $e->getMessage()], 500);
    }
}

// ── VOID SALE (Owner only) ────────────────────────────────────
if ($action === 'void') {
    requireRole(['Owner']);
    $body = json_decode(file_get_contents('php://input'), true);
    $id   = (int)($body['id'] ?? 0);
    if (!$id) jsonOut(['ok' => false, 'error' => 'Invalid id'], 400);

    $stmt = $db->prepare('SELECT * FROM sales WHERE id = ? AND voided = 0');
    $stmt->execute([$id]);
    $sale = $stmt->fetch();
    if (!$sale) jsonOut(['ok' => false, 'error' => 'Sale not found or already voided'], 404);

    $db->beginTransaction();
    try {
        $db->prepare('UPDATE sales SET voided = 1 WHERE id = ?')->execute([$id]);
        // Restore stock
        $db->prepare('UPDATE products SET stock = stock + ? WHERE id = ?')->execute([$sale['qty'], $sale['product_id']]);
        $db->prepare('INSERT INTO audit_log (action_type, details, done_by) VALUES (?,?,?)')
           ->execute(['VOID', "Voided sale #{$id}: {$sale['product_name']} x{$sale['qty']} RWF {$sale['total']}", $_SESSION['full_name']]);
        $db->commit();
        jsonOut(['ok' => true]);
    } catch (Exception $e) {
        $db->rollBack();
        jsonOut(['ok' => false, 'error' => $e->getMessage()], 500);
    }
}

jsonOut(['ok' => false, 'error' => 'Unknown action'], 400);
