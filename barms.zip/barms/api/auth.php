<?php
// ============================================================
//  api/auth.php — Login / Logout / Session check
// ============================================================

// Start session before anything else
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/db.php';

$action = $_REQUEST['action'] ?? '';

// ── LOGIN ─────────────────────────────────────────────────────
if ($action === 'login') {
    $body     = json_decode(file_get_contents('php://input'), true);
    $username = strtolower(trim($body['username'] ?? ''));
    $password = $body['password'] ?? '';

    if (!$username || !$password) {
        jsonOut(['ok' => false, 'error' => 'Username and password required'], 400);
    }

    $db   = getDB();
    $stmt = $db->prepare('SELECT * FROM users WHERE username = ? AND active = 1 LIMIT 1');
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    // Support both MD5 and bcrypt passwords
    $validPassword = false;
    if ($user) {
        if ($user['password'] === md5($password)) {
            $validPassword = true;
        } elseif (password_verify($password, $user['password'])) {
            $validPassword = true;
        }
    }

    if (!$user || !$validPassword) {
        jsonOut(['ok' => false, 'error' => 'Invalid credentials'], 401);
    }

    // Store session
    $_SESSION['user_id']   = $user['id'];
    $_SESSION['username']  = $user['username'];
    $_SESSION['full_name'] = $user['full_name'];
    $_SESSION['role']      = $user['role'];

    // Log audit
    try {
        $db->prepare('INSERT INTO audit_log (action_type, details, done_by) VALUES (?, ?, ?)')
           ->execute(['LOGIN', $user['full_name'] . ' logged in as ' . $user['role'], $user['full_name']]);
    } catch (Exception $e) {}

    // Pending void requests
    $pendingVoids = 0;
    if (in_array($user['role'], ['Owner', 'Manager'])) {
        try {
            $vStmt = $db->query("SELECT COUNT(*) AS cnt FROM void_requests WHERE status='Pending'");
            $pendingVoids = (int)$vStmt->fetch()['cnt'];
        } catch (Exception $e) {}
    }

    jsonOut([
        'ok'          => true,
        'user'        => [
            'id'       => $user['id'],
            'username' => $user['username'],
            'fullName' => $user['full_name'],
            'role'     => $user['role'],
        ],
        'pendingVoids' => $pendingVoids,
    ]);
}

// ── LOGOUT ────────────────────────────────────────────────────
if ($action === 'logout') {
    session_destroy();
    jsonOut(['ok' => true]);
}

// ── SESSION CHECK ─────────────────────────────────────────────
if ($action === 'me') {
    if (empty($_SESSION['user_id'])) {
        jsonOut(['ok' => false, 'error' => 'Not logged in'], 401);
    }
    jsonOut([
        'ok'   => true,
        'user' => [
            'id'       => $_SESSION['user_id'],
            'username' => $_SESSION['username'],
            'fullName' => $_SESSION['full_name'],
            'role'     => $_SESSION['role'],
        ],
    ]);
}

// ── CHANGE PASSWORD ───────────────────────────────────────────
if ($action === 'change_password') {
    if (empty($_SESSION['user_id'])) {
        jsonOut(['ok' => false, 'error' => 'Not authenticated'], 401);
    }
    $body    = json_decode(file_get_contents('php://input'), true);
    $current = $body['current'] ?? '';
    $newPwd  = $body['new']     ?? '';

    if (!$current || !$newPwd) jsonOut(['ok' => false, 'error' => 'Fill both fields'], 400);

    $db   = getDB();
    $stmt = $db->prepare('SELECT password FROM users WHERE id = ?');
    $stmt->execute([$_SESSION['user_id']]);
    $row  = $stmt->fetch();

    $valid = false;
    if ($row['password'] === md5($current)) $valid = true;
    elseif (password_verify($current, $row['password'])) $valid = true;

    if (!$valid) jsonOut(['ok' => false, 'error' => 'Current password is wrong'], 401);

    // Save as MD5
    $db->prepare('UPDATE users SET password = ? WHERE id = ?')
       ->execute([md5($newPwd), $_SESSION['user_id']]);

    jsonOut(['ok' => true]);
}

jsonOut(['ok' => false, 'error' => 'Unknown action'], 400);
