<?php
// ============================================================
//  api/misc.php — Settings, Users, Void Requests,
//                 Audit Log, Customer Debts, Notifications,
//                 Manager Permissions, Dashboard stats
// ============================================================
require_once __DIR__ . '/../config/db.php';


$action = $_REQUEST['action'] ?? '';
$db     = getDB();

// ══════════════════════════════════════════════════════════════
//  SETTINGS
// ══════════════════════════════════════════════════════════════
if ($action === 'settings_get') {
    requireAuth();
    $stmt = $db->query('SELECT * FROM settings LIMIT 1');
    $row  = $stmt->fetch();
    jsonOut(['ok' => true, 'data' => [
        'barName'  => $row['bar_name'],
        'location' => $row['location'],
        'currency' => $row['currency'],
    ]]);
}

if ($action === 'settings_save') {
    requireRole(['Owner']);
    $body    = json_decode(file_get_contents('php://input'), true);
    $barName = trim($body['barName'] ?? 'BarMS Pro');
    $location= trim($body['location'] ?? 'Kigali, Rwanda');
    $currency= trim($body['currency'] ?? 'RWF');
    $db->prepare('UPDATE settings SET bar_name=?, location=?, currency=? WHERE id=1')
       ->execute([$barName, $location, $currency]);
    $db->prepare('INSERT INTO audit_log (action_type, details, done_by) VALUES (?,?,?)')
       ->execute(['SETTINGS', 'Updated bar settings', $_SESSION['full_name']]);
    jsonOut(['ok' => true]);
}

// ══════════════════════════════════════════════════════════════
//  USERS (system login accounts)
// ══════════════════════════════════════════════════════════════
if ($action === 'users_list') {
    requireRole(['Owner']);
    $stmt = $db->query("SELECT id, full_name, username, role, active FROM users WHERE active=1 ORDER BY id ASC");
    $rows = $stmt->fetchAll();
    foreach ($rows as &$r) {
        $r['id']       = (int)$r['id'];
        $r['active']   = (bool)$r['active'];
        $r['fullName'] = $r['full_name'];
    }
    jsonOut(['ok' => true, 'data' => $rows]);
}

if ($action === 'users_add') {
    // Check session - debug version
    $sessionUser = $_SESSION['user_id'] ?? null;
    $sessionRole = $_SESSION['role'] ?? null;
    
    if (!$sessionUser) {
        jsonOut(['ok' => false, 'error' => 'Not logged in - session missing. Please logout and login again.'], 401);
    }
    if ($sessionRole !== 'Owner') {
        jsonOut(['ok' => false, 'error' => 'Access denied - your role is: ' . $sessionRole], 403);
    }
    
    try {
        // Read JSON body
        $rawBody  = file_get_contents('php://input');
        $body     = json_decode($rawBody, true) ?? [];
        
        // Fallback to POST params if JSON empty
        if (empty($body)) {
            $body = $_POST;
        }
        
        $fullName = trim($body['fullName'] ?? $_POST['fullName'] ?? '');
        $username = strtolower(trim($body['username'] ?? $_POST['username'] ?? ''));
        $password = $body['password'] ?? $_POST['password'] ?? '';
        $role     = $body['role'] ?? $_POST['role'] ?? 'Bartender';

        if (!$fullName || !$username || !$password) {
            jsonOut(['ok' => false, 'error' => 'Fields empty. Body received: '.strlen($rawBody).' bytes. fullName='.($fullName?'yes':'no').', user='.($username?'yes':'no').', pass='.($password?'yes':'no')], 400);
        }

        $chk = $db->prepare('SELECT id FROM users WHERE username = ?');
        $chk->execute([$username]);
        if ($chk->fetch()) jsonOut(['ok' => false, 'error' => 'Username already exists'], 400);

        $db->prepare('INSERT INTO users (full_name, username, password, role, active) VALUES (?, ?, ?, ?, 1)')
           ->execute([$fullName, $username, md5($password), $role]);
        $newId = (int)$db->lastInsertId();

        try {
            $db->prepare('INSERT INTO audit_log (action_type, details, done_by) VALUES (?, ?, ?)')
               ->execute(['USER_ADD', "Added: $username ($role)", $_SESSION['full_name'] ?? 'system']);
        } catch (Exception $logErr) {}

        jsonOut(['ok' => true, 'id' => $newId]);
    } catch (Exception $e) {
        jsonOut(['ok' => false, 'error' => 'DB error: ' . $e->getMessage()], 500);
    }
}

if ($action === 'users_remove') {
    $sess = requireAuth();
    if ($sess['role'] !== 'Owner') {
        jsonOut(['ok' => false, 'error' => 'Only Owner can remove users'], 403);
    }
    try {
        $body = json_decode(file_get_contents('php://input'), true) ?? [];
        $id   = (int)($body['id'] ?? 0);
        if (!$id) jsonOut(['ok' => false, 'error' => 'Invalid user'], 400);
        if ($id === (int)$_SESSION['user_id']) jsonOut(['ok' => false, 'error' => "Cannot remove yourself"], 400);
        $db->prepare('UPDATE users SET active = 0 WHERE id = ?')->execute([$id]);
        try {
            $db->prepare('INSERT INTO audit_log (action_type, details, done_by) VALUES (?, ?, ?)')
               ->execute(['USER_REMOVE', "Removed user id: $id", $_SESSION['full_name'] ?? 'system']);
        } catch (Exception $logErr) { /* ignore */ }
        jsonOut(['ok' => true]);
    } catch (Exception $e) {
        jsonOut(['ok' => false, 'error' => 'Server error: ' . $e->getMessage()], 500);
    }
}

// ══════════════════════════════════════════════════════════════
//  VOID REQUESTS
// ══════════════════════════════════════════════════════════════
if ($action === 'void_requests_list') {
    requireRole(['Owner', 'Manager']);
    $stmt = $db->query('SELECT * FROM void_requests ORDER BY id DESC');
    $rows = $stmt->fetchAll();
    foreach ($rows as &$r) {
        $r['id']     = (int)$r['id'];
        $r['ref_id'] = (int)$r['ref_id'];
        $r['amount'] = (float)$r['amount'];
        $r['refId']  = $r['ref_id'];
        $r['requestedBy'] = $r['requested_by'];
        $r['reviewedBy']  = $r['reviewed_by'];
        $r['createdAt']   = $r['created_at'];
    }
    jsonOut(['ok' => true, 'data' => $rows]);
}

if ($action === 'void_request_submit') {
    requireRole(['Manager']);
    $sess = $_SESSION;
    $body = json_decode(file_get_contents('php://input'), true);
    $type   = $body['type']   ?? 'sale';
    $refId  = (int)($body['refId'] ?? 0);
    $label  = trim($body['label'] ?? '');
    $amount = (float)($body['amount'] ?? 0);
    $reason = trim($body['reason'] ?? '');
    if (!$refId || !$label) jsonOut(['ok' => false, 'error' => 'Invalid request'], 400);
    $db->prepare('INSERT INTO void_requests (type, ref_id, label, amount, reason, requested_by) VALUES (?,?,?,?,?,?)')
       ->execute([$type, $refId, $label, $amount, $reason, $sess['full_name']]);
    jsonOut(['ok' => true, 'id' => (int)$db->lastInsertId()]);
}

if ($action === 'void_request_approve') {
    requireRole(['Owner']);
    $sess = $_SESSION;
    $body = json_decode(file_get_contents('php://input'), true);
    $id   = (int)($body['id'] ?? 0);
    if (!$id) jsonOut(['ok' => false, 'error' => 'Invalid id'], 400);

    $stmt = $db->prepare('SELECT * FROM void_requests WHERE id=? AND status="Pending"');
    $stmt->execute([$id]);
    $req = $stmt->fetch();
    if (!$req) jsonOut(['ok' => false, 'error' => 'Request not found or already processed'], 404);

    $db->beginTransaction();
    try {
        $db->prepare("UPDATE void_requests SET status='Approved', reviewed_by=?, reviewed_at=NOW() WHERE id=?")
           ->execute([$sess['full_name'], $id]);

        // Apply the void
        if ($req['type'] === 'sale') {
            $sSt = $db->prepare('SELECT * FROM sales WHERE id=? AND voided=0');
            $sSt->execute([$req['ref_id']]);
            $sale = $sSt->fetch();
            if ($sale) {
                $db->prepare('UPDATE sales SET voided=1 WHERE id=?')->execute([$req['ref_id']]);
                $db->prepare('UPDATE products SET stock=stock+? WHERE id=?')->execute([$sale['qty'], $sale['product_id']]);
            }
        } elseif ($req['type'] === 'expense') {
            $db->prepare('UPDATE expenses SET voided=1 WHERE id=?')->execute([$req['ref_id']]);
        } elseif ($req['type'] === 'kitrev') {
            $db->prepare('DELETE FROM kitchen_revenue WHERE id=?')->execute([$req['ref_id']]);
        }

        $db->prepare('INSERT INTO audit_log (action_type, details, done_by) VALUES (?,?,?)')
           ->execute(['VOID', "Approved void request #{$id}: {$req['label']}", $sess['full_name']]);

        $db->commit();
        jsonOut(['ok' => true]);
    } catch (Exception $e) {
        $db->rollBack();
        jsonOut(['ok' => false, 'error' => $e->getMessage()], 500);
    }
}

if ($action === 'void_request_reject') {
    requireRole(['Owner']);
    $sess = $_SESSION;
    $body = json_decode(file_get_contents('php://input'), true);
    $id   = (int)($body['id'] ?? 0);
    $db->prepare("UPDATE void_requests SET status='Rejected', reviewed_by=?, reviewed_at=NOW() WHERE id=?")
       ->execute([$sess['full_name'], $id]);
    jsonOut(['ok' => true]);
}

// ══════════════════════════════════════════════════════════════
//  AUDIT LOG
// ══════════════════════════════════════════════════════════════
if ($action === 'audit_list') {
    requireRole(['Owner', 'Manager']);
    $filter = $_GET['filter'] ?? '';
    $type   = $_GET['type']   ?? '';
    $sql    = 'SELECT * FROM audit_log';
    $params = [];
    if ($filter) {
        $sql .= ' WHERE (details LIKE ? OR done_by LIKE ? OR action_type LIKE ?)';
        $params = ["%$filter%", "%$filter%", "%$filter%"];
    } elseif ($type) {
        $sql .= ' WHERE action_type = ?';
        $params = [$type];
    }
    $sql .= ' ORDER BY id DESC LIMIT 500';
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();
    foreach ($rows as &$r) {
        $r['id']     = (int)$r['id'];
        $r['by']     = $r['done_by'];
        $r['type']   = $r['action_type'];
        $r['time']   = $r['done_at'];
    }
    jsonOut(['ok' => true, 'data' => $rows]);
}

if ($action === 'audit_add') {
    $sess = requireAuth();
    $body = json_decode(file_get_contents('php://input'), true);
    $type    = $body['type']    ?? 'ACTION';
    $details = $body['details'] ?? '';
    $db->prepare('INSERT INTO audit_log (action_type, details, done_by) VALUES (?,?,?)')
       ->execute([$type, $details, $sess['full_name']]);
    jsonOut(['ok' => true]);
}

// ══════════════════════════════════════════════════════════════
//  CUSTOMER DEBTS
// ══════════════════════════════════════════════════════════════
if ($action === 'cust_debts_list') {
    requireAuth();
    $stmt = $db->query('SELECT * FROM customer_debts ORDER BY id DESC');
    $rows = $stmt->fetchAll();
    foreach ($rows as &$r) {
        $r['id']     = (int)$r['id'];
        $r['amount'] = (float)$r['amount'];
        $r['customerName'] = $r['customer_name'];
        $r['by']           = $r['recorded_by'];
        $r['date']         = $r['debt_date'];
    }
    jsonOut(['ok' => true, 'data' => $rows]);
}

if ($action === 'cust_debt_save') {
    requireAuth();
    $sess = $_SESSION;
    $body = json_decode(file_get_contents('php://input'), true);
    $name   = trim($body['customerName'] ?? '');
    $phone  = trim($body['phone'] ?? '');
    $amount = (float)($body['amount'] ?? 0);
    $note   = trim($body['note'] ?? '');
    $date   = $body['date'] ?? date('Y-m-d');
    if (!$name || $amount <= 0) jsonOut(['ok' => false, 'error' => 'Name and amount required'], 400);
    $db->prepare('INSERT INTO customer_debts (customer_name, phone, amount, note, debt_date, recorded_by) VALUES (?,?,?,?,?,?)')
       ->execute([$name, $phone, $amount, $note, $date, $sess['full_name']]);
    jsonOut(['ok' => true, 'id' => (int)$db->lastInsertId()]);
}

if ($action === 'cust_debt_paid') {
    requireAuth();
    $body = json_decode(file_get_contents('php://input'), true);
    $id   = (int)($body['id'] ?? 0);
    $db->prepare("UPDATE customer_debts SET status='Paid' WHERE id=?")->execute([$id]);
    jsonOut(['ok' => true]);
}

if ($action === 'cust_debt_delete') {
    requireRole(['Owner']);
    $body = json_decode(file_get_contents('php://input'), true);
    $id   = (int)($body['id'] ?? 0);
    $db->prepare('DELETE FROM customer_debts WHERE id=?')->execute([$id]);
    jsonOut(['ok' => true]);
}

// ══════════════════════════════════════════════════════════════
//  NOTIFICATIONS
// ══════════════════════════════════════════════════════════════
if ($action === 'notif_list') {
    requireAuth();
    $stmt = $db->query('SELECT * FROM notifications ORDER BY id DESC LIMIT 50');
    $rows = $stmt->fetchAll();
    foreach ($rows as &$r) {
        $r['id']      = (int)$r['id'];
        $r['read']    = (bool)$r['is_read'];
        $r['text']    = $r['message'];
        $r['time']    = $r['created_at'];
    }
    jsonOut(['ok' => true, 'data' => $rows]);
}

if ($action === 'notif_mark_read') {
    requireAuth();
    $db->query('UPDATE notifications SET is_read=1');
    jsonOut(['ok' => true]);
}

if ($action === 'notif_add') {
    requireAuth();
    $body = json_decode(file_get_contents('php://input'), true);
    $msg  = trim($body['text'] ?? '');
    $type = $body['type'] ?? 'info';
    if ($msg) {
        $db->prepare('INSERT INTO notifications (message, type) VALUES (?,?)')->execute([$msg, $type]);
    }
    jsonOut(['ok' => true]);
}

// ══════════════════════════════════════════════════════════════
//  MANAGER PERMISSIONS
// ══════════════════════════════════════════════════════════════
if ($action === 'mgr_perms_get') {
    requireAuth();
    $stmt = $db->query('SELECT * FROM mgr_permissions LIMIT 1');
    $row  = $stmt->fetch();
    jsonOut(['ok' => true, 'data' => [
        'canViewReports'   => (bool)$row['can_view_reports'],
        'canEditStock'     => (bool)$row['can_edit_stock'],
        'canEditProducts'  => (bool)$row['can_edit_products'],
        'canViewEmployees' => (bool)$row['can_view_employees'],
        'canViewAudit'     => (bool)$row['can_view_audit'],
    ]]);
}

if ($action === 'mgr_perms_save') {
    requireRole(['Owner']);
    $body = json_decode(file_get_contents('php://input'), true);
    $db->prepare('UPDATE mgr_permissions SET can_view_reports=?, can_edit_stock=?, can_edit_products=?, can_view_employees=?, can_view_audit=? WHERE id=1')
       ->execute([
           (int)($body['canViewReports']   ?? 1),
           (int)($body['canEditStock']     ?? 1),
           (int)($body['canEditProducts']  ?? 1),
           (int)($body['canViewEmployees'] ?? 1),
           (int)($body['canViewAudit']     ?? 0),
       ]);
    jsonOut(['ok' => true]);
}

// ══════════════════════════════════════════════════════════════
//  DASHBOARD STATS (all-in-one for speed)
// ══════════════════════════════════════════════════════════════
if ($action === 'dashboard') {
    $sess = requireAuth();
    $today = date('Y-m-d');
    $month = date('Y-m');

    // Today's sales
    $stmt = $db->prepare("SELECT COALESCE(SUM(total),0) AS rev FROM sales WHERE sale_date=? AND voided=0");
    $stmt->execute([$today]);
    $todayRev = (float)$stmt->fetch()['rev'];

    // Today's transactions count
    $stmt = $db->prepare("SELECT COUNT(*) AS cnt FROM sales WHERE sale_date=? AND voided=0");
    $stmt->execute([$today]);
    $todayTx = (int)$stmt->fetch()['cnt'];

    // Month revenue
    $stmt = $db->prepare("SELECT COALESCE(SUM(total),0) AS rev FROM sales WHERE sale_date LIKE ? AND voided=0");
    $stmt->execute([$month . '%']);
    $monthRev = (float)$stmt->fetch()['rev'];

    // Today expenses
    $stmt = $db->prepare("SELECT COALESCE(SUM(amount),0) AS exp FROM expenses WHERE expense_date=? AND voided=0");
    $stmt->execute([$today]);
    $todayExp = (float)$stmt->fetch()['exp'];

    // Low stock count + total products
    $lowStock     = (int)$db->query('SELECT COUNT(*) AS cnt FROM products WHERE active=1 AND stock <= alert_level')->fetch()['cnt'];
    $totalProducts= (int)$db->query('SELECT COUNT(*) AS cnt FROM products WHERE active=1')->fetch()['cnt'];

    // Pending void requests
    $pendingVoids = (int)$db->query("SELECT COUNT(*) AS cnt FROM void_requests WHERE status='Pending'")->fetch()['cnt'];

    // Kitchen revenue today
    $stmt = $db->prepare("SELECT COALESCE(SUM(amount),0) AS rev FROM kitchen_revenue WHERE revenue_date=?");
    $stmt->execute([$today]);
    $kitchenRevToday = (float)$stmt->fetch()['rev'];

    // Unread notifications
    $unreadNotifs = (int)$db->query("SELECT COUNT(*) AS cnt FROM notifications WHERE is_read=0")->fetch()['cnt'];

    // COGS today (sum of cost_price * qty for today's sales)
    $stmt = $db->prepare("SELECT COALESCE(SUM(p.cost_price * s.qty),0) AS cogs FROM sales s JOIN products p ON s.product_id=p.id WHERE s.sale_date=? AND s.voided=0");
    $stmt->execute([$today]);
    $cogsToday = (float)$stmt->fetch()['cogs'];

    // Kitchen expenses today
    $stmt = $db->prepare("SELECT COALESCE(SUM(amount),0) AS exp FROM kitchen_expenses WHERE expense_date=?");
    $stmt->execute([$today]);
    $kitchenExpToday = (float)$stmt->fetch()['exp'];

    // Bar Gross Profit = Revenue - COGS (selling price - buying price) * qty
    $barGrossProfit = $todayRev - $cogsToday;

    // Bar Net Profit = Bar Gross Profit - Bar Expenses
    $barNetProfit = $barGrossProfit - $todayExp;

    // Kitchen Net Profit = Kitchen Gross Profit - Kitchen Expenses
    $kitchenNetProfit = $kitchenRevToday - $kitchenExpToday;

    // Total Net Profit = Bar Net Profit + Kitchen Net Profit
    $totalNetProfit = $barNetProfit + $kitchenNetProfit;

    // Net Cash Flow = Total Net Profit
    $netCashFlow = $totalNetProfit;

    // Recent sales (today, last 10)
    $stmt = $db->prepare("SELECT * FROM sales WHERE sale_date=? AND voided=0 ORDER BY id DESC LIMIT 10");
    $stmt->execute([$today]);
    $recentSales = $stmt->fetchAll();
    foreach ($recentSales as &$r) {
        $r['total']       = (float)$r['total'];
        $r['qty']         = (int)$r['qty'];
        $r['productName'] = $r['product_name'];
        $r['soldBy']      = $r['sold_by'];
        $r['date']        = $r['sale_date'];
        $r['time']        = substr($r['sale_time'], 0, 5);
    }

    // Monthly sales for chart (last 6 months)
    $stmt = $db->query("SELECT DATE_FORMAT(sale_date,'%Y-%m') AS mo, SUM(total) AS rev FROM sales WHERE voided=0 AND sale_date >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH) GROUP BY mo ORDER BY mo ASC");
    $monthlySales = $stmt->fetchAll();

    jsonOut(['ok' => true, 'data' => [
        'todayRevenue'      => $todayRev,
        'todayTx'           => $todayTx,
        'monthRevenue'      => $monthRev,
        'todayExpenses'     => $todayExp,
        'todayProfit'       => $totalNetProfit,
        'barGrossProfit'    => $barGrossProfit,
        'barGrossProfit'    => $barGrossProfit,
        'barNetProfit'      => $barNetProfit,
        'kitchenNetProfit'  => $kitchenNetProfit,
        'totalNetProfit'    => $totalNetProfit,
        'netCashFlow'       => $netCashFlow,
        'lowStockCount'     => $lowStock,
        'totalProducts'     => $totalProducts,
        'pendingVoids'      => $pendingVoids,
        'kitchenRevenue'    => $kitchenRevToday,
        'kitchenExpenses'   => $kitchenExpToday,
        'unreadNotifs'      => $unreadNotifs,
        'todayCogs'         => $cogsToday,
        'recentSales'       => $recentSales,
        'monthlySales'   => $monthlySales,
    ]]);
}

// ══════════════════════════════════════════════════════════════
//  REPORTS (date-range aggregation)
// ══════════════════════════════════════════════════════════════
if ($action === 'report') {
    requireRole(['Owner', 'Manager']);
    $type  = $_GET['type']  ?? 'daily';
    $date  = $_GET['date']  ?? date('Y-m-d');
    $month = $_GET['month'] ?? date('Y-m');
    $from  = $_GET['from']  ?? date('Y-m-01');
    $to    = $_GET['to']    ?? date('Y-m-d');

    if ($type === 'daily')   { $sWhere = 'sale_date = ?';     $eWhere = 'expense_date = ?';  $sParam = $eParam = [$date]; }
    elseif ($type === 'monthly') { $sWhere = 'sale_date LIKE ?'; $eWhere = 'expense_date LIKE ?'; $sParam = $eParam = [$month.'%']; }
    else { $sWhere = 'sale_date BETWEEN ? AND ?'; $eWhere = 'expense_date BETWEEN ? AND ?'; $sParam = $eParam = [$from, $to]; }

    $stmt = $db->prepare("SELECT * FROM sales WHERE $sWhere ORDER BY id DESC");
    $stmt->execute($sParam);
    $sales = $stmt->fetchAll();
    foreach ($sales as &$s) {
        $s['id'] = (int)$s['id']; $s['total'] = (float)$s['total'];
        $s['qty'] = (int)$s['qty']; $s['unit_price'] = (float)$s['unit_price'];
        $s['voided'] = (bool)$s['voided'];
        $s['productName'] = $s['product_name']; $s['soldBy'] = $s['sold_by'];
        $s['date'] = $s['sale_date']; $s['time'] = substr($s['sale_time'],0,5);
        $s['unitPrice'] = $s['unit_price'];
    }

    $stmt = $db->prepare("SELECT * FROM expenses WHERE $eWhere ORDER BY id DESC");
    $stmt->execute($eParam);
    $expenses = $stmt->fetchAll();
    foreach ($expenses as &$e) {
        $e['id'] = (int)$e['id']; $e['amount'] = (float)$e['amount'];
        $e['voided'] = (bool)$e['voided'];
        $e['desc'] = $e['description']; $e['date'] = $e['expense_date']; $e['by'] = $e['recorded_by'];
    }

    $totalRev = array_sum(array_map(fn($s) => $s['voided'] ? 0 : $s['total'], $sales));
    $totalExp = array_sum(array_map(fn($e) => $e['voided'] ? 0 : $e['amount'], $expenses));

    // COGS for period (cost_price * qty)
    $stmt = $db->prepare("SELECT COALESCE(SUM(p.cost_price * s.qty),0) AS cogs FROM sales s JOIN products p ON s.product_id=p.id WHERE $sWhere AND s.voided=0");
    $stmt->execute($sParam);
    $totalCogs = (float)$stmt->fetch()['cogs'];

    // Kitchen revenue for period
    if ($type === 'daily')        { $kWhere = 'revenue_date = ?';     $kParam = [$date]; }
    elseif ($type === 'monthly')  { $kWhere = 'revenue_date LIKE ?';  $kParam = [$month.'%']; }
    else                          { $kWhere = 'revenue_date BETWEEN ? AND ?'; $kParam = [$from, $to]; }

    $stmt = $db->prepare("SELECT COALESCE(SUM(amount),0) AS rev FROM kitchen_revenue WHERE $kWhere");
    $stmt->execute($kParam);
    $kitRev = (float)$stmt->fetch()['rev'];

    // Kitchen expenses for period
    if ($type === 'daily')        { $keWhere = 'expense_date = ?';     $keParam = [$date]; }
    elseif ($type === 'monthly')  { $keWhere = 'expense_date LIKE ?';  $keParam = [$month.'%']; }
    else                          { $keWhere = 'expense_date BETWEEN ? AND ?'; $keParam = [$from, $to]; }

    $stmt = $db->prepare("SELECT COALESCE(SUM(amount),0) AS exp FROM kitchen_expenses WHERE $keWhere");
    $stmt->execute($keParam);
    $kitExp = (float)$stmt->fetch()['exp'];

    // Bar Gross Profit = Revenue - COGS
    $barGrossProfit = $totalRev - $totalCogs;

    // Bar Net Profit = Bar Gross Profit - Bar Expenses
    $barNetProfit = $barGrossProfit - $totalExp;

    // Kitchen Net Profit = Kitchen Gross Profit Revenue - Kitchen Expenses
    $kitchenNetProfit = $kitRev - $kitExp;

    // Total Net Profit = Bar Net Profit + Kitchen Net Profit
    $totalNetProfit = $barNetProfit + $kitchenNetProfit;

    jsonOut(['ok' => true, 'data' => [
        'sales'             => $sales,
        'expenses'          => $expenses,
        'totalRev'          => $totalRev,
        'totalExp'          => $totalExp,
        'totalCogs'         => $totalCogs,
        'kitRev'            => $kitRev,
        'kitExp'            => $kitExp,
        'barGrossProfit'    => $barGrossProfit,
        'barNetProfit'      => $barNetProfit,
        'kitchenNetProfit'  => $kitchenNetProfit,
        'totalNetProfit'    => $totalNetProfit,
        'profit'            => $totalNetProfit,
    ]]);
}

jsonOut(['ok' => false, 'error' => 'Unknown action'], 400);
